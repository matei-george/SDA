package magazin;

import cutii.TipCutie;
import cutii.iCutie;
import jucarii.Jucarie;

public class FabricaCutii {
    public void getCutie(Jucarie jucarie){
    }
}
