package magazin;

public class RolaPanglica {
    private final int LungimeDisponibila=10000; //> CM
    private final double costUnitateLungime=0.01;
}
