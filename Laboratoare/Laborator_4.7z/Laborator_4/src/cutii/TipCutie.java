package cutii;

public enum TipCutie {
    PARALELIPIPED, CUB, CILINDRU;
}